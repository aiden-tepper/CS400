#README

Course: cs400

Semester: Fall 2019

Project name: Milk Weights

ateam: 152

Team Members:
1. Aiden Tepper, lecture 1, ajtepper@wisc.edu
2. Charlie Rodriguez, lecture 1, jcrodriguez3@wisc.edu
 
Both team members were on the same x-team (182)  
  
**Bug Report + Future Work**

No current bugs are known.

Future work would include adding more ways to analyze and manipulate imported data, as well as further polishing and refining the UI to make the design more aesthetically pleasing.